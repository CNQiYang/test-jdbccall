create function getrecord(in_id integer, OUT out_name character varying, OUT out_age integer) returns record
LANGUAGE SQL
AS $$
SELECT name, age
FROM Student where id = in_id
$$;
