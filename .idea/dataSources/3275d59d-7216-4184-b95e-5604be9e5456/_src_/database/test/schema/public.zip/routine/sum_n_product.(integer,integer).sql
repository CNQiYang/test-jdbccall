create function sum_n_product(x integer, y integer, OUT sum integer, OUT product integer) returns record
LANGUAGE SQL
AS $$
SELECT x + y, x * y
$$;
